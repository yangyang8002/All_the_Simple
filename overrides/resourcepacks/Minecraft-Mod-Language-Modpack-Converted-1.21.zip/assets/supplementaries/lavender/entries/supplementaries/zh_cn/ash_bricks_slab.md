```json
{
  "title": "灰烬砖台阶",
  "icon": "supplementaries:ash_bricks_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/slabs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:ash_bricks_slab"
  ]
}
```

&spotlight(supplementaries:ash_bricks_slab)
**灰烬砖台阶**是[灰烬砖块](^supplementaries:ash_bricks)的[台阶](^minecraft:tag/slabs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:ash_brick_slab>
<recipe;supplementaries:stonecutting/ash_brick_slab_from_bricks>

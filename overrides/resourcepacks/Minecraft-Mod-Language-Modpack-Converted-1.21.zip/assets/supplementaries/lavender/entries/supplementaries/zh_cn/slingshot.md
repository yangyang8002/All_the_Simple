```json
{
  "title": "弹弓",
  "icon": "supplementaries:slingshot",
  "categories": [
    "minecraft:items",
    "minecraft:group/tools_and_utilities"
  ],
  "associated_items": [
    "supplementaries:slingshot"
  ]
}
```

&spotlight(supplementaries:slingshot)
**弹弓**是能发射方块的工具！

;;;;;

&title(合成)
<recipe;supplementaries:slingshot>

;;;;;

&title(用途)
发射出去的方块会在着陆点合适时在该处放置自身。


接受快速装填、多重射击、[稳定](^supplementaries:stasis)魔咒。

```json
{
  "title": "音乐唱片《Heave Ho!》",
  "icon": "supplementaries:music_disc_heave_ho",
  "categories": [
    "minecraft:items",
    "minecraft:tag/music_discs"
  ],
  "associated_items": [
    "supplementaries:music_disc_heave_ho"
  ]
}
```

&spotlight(supplementaries:music_disc_heave_ho)
《**Heave Ho!**》是一张[音乐唱片](^minecraft:tag/music_discs)，由向苦力怕发射[炮弹](^supplementaries:cannonball)获得。

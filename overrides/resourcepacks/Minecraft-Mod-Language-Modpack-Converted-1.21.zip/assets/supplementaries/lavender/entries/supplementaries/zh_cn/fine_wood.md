```json
{
  "title": "细木堆",
  "icon": "supplementaries:fine_wood",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:fine_wood"
  ]
}
```

&spotlight(supplementaries:fine_wood)
**细木堆**是一种装饰性方块。

;;;;;

&title(合成)
<recipe;supplementaries:fine_wood>

;;;;;

&title(合成材料)
<recipe;supplementaries:fine_wood_slab>
<recipe;supplementaries:fine_wood_stairs>


```json
{
  "title": "黑石瓦",
  "icon": "supplementaries:blackstone_tile",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:blackstone_tile"
  ]
}
```

&spotlight(supplementaries:blackstone_tile)
**黑石瓦**是[黑石](^minecraft:blackstone)的装饰性变种。

;;;;;

&title(合成)
<recipe;supplementaries:blackstone_tile>
<recipe;supplementaries:stonecutting/blackstone_tile>

;;;;;

&title(合成材料)
<recipe;supplementaries:blackstone_tile_slab>
<recipe;supplementaries:blackstone_tile_stairs>

;;;;;

&title(烧炼材料)
<recipe;supplementaries:blackstone_tile_wall>


;;;;;

&title(切石材料)
<recipe;supplementaries:stonecutting/blackstone_tile_slab>
<recipe;supplementaries:stonecutting/blackstone_tile_stairs_from_bricks>
<recipe;supplementaries:stonecutting/blackstone_tile_wall_from_bricks>

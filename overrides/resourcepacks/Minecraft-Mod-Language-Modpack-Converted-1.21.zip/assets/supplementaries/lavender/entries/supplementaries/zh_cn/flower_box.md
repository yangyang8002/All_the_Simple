```json
{
  "title": "花箱",
  "icon": "supplementaries:flower_box",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:flower_box"
  ]
}
```

&spotlight(supplementaries:flower_box)
**花箱**中能够种植[大型花](^minecraft:tag/tall_flowers)与类似植物，如藤蔓、[洞穴藤蔓](^minecraft:glow_berries)、垂泪藤、缠怨藤等。


<block;supplementaries:flower_box>

;;;;;

&title(合成)
<recipe;supplementaries:flower_box>

;;;;;

&title(用途)
可在配置中改为最多可栽种3株植物。


可以放在方块的中央和侧边，也可挂在方块底面。

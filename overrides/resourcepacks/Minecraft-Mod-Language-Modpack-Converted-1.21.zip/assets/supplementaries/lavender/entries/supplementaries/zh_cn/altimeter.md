```json
{
  "title": "海拔计",
  "icon": "supplementaries:altimeter",
  "categories": [
    "minecraft:items",
    "minecraft:group/tools_and_utilities"
  ],
  "associated_items": [
    "supplementaries:altimeter"
  ]
}
```

&spotlight(supplementaries:altimeter)
**海拔计**是能通过视觉效果显示当前高度的工具。

;;;;;

&title(合成)
<recipe;supplementaries:altimeter>

;;;;;

&title(用途)
物品的纹理会随所处高度和维度不同而变化。默认情况下，所处高度每增加4格，纹理向上增加1像素。


<keybind;key.use>会显示Y轴坐标。

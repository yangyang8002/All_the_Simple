```json
{
  "title": "稳定",
  "icon": "minecraft:enchanted_book[stored_enchantments={levels:{'supplementaries:stasis':1}}]",
  "category": "minecraft:enchantments",
  "associated_items": [
    "minecraft:enchanted_book[stored_enchantments={levels:{'supplementaries:stasis':1}}]"
  ]
}
```

**稳定**是专为[弹弓](^supplementaries:slingshot)和[泡泡环](^supplementaries:bubble_blower)设置的魔咒，可在末地城中找到。

;;;;;

&title(弹弓)
带有稳定魔咒的[弹弓](^supplementaries:slingshot)能够沿直线射出弹射物，即不受重力影响；持有时还会在命中点显示白色的方块轮廓。

;;;;;

&title(泡泡环)
带有稳定魔咒的[泡泡环](^supplementaries:bubble_blower)获得了一项有实际用途的功能：能够在空中所看处放置漂亮的[肥皂泡方块](^supplementaries:soap_block)。

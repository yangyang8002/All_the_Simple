---
id: networking_tool
---

# Networking Tool

The Networking Tool allows NEEPBus output ports to be quickly connected to input ports.

## Usage

A menu will appear when holding the tool and focusing on a participant block. Scroll to select the desired output port and click to copy its address. Focus on the target participant block, scroll to select the desired input port, and click to set the address.

Sneak-use on a NEEPBus participant to access its address configuration.
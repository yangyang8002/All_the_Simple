```json
{
  "title": "曲变术",
  "icon": "trickster:scroll_and_quill",
  "ordinal": 2,
  "parent": "trickster:tricks"
}
```

曲变术是仅对数据进行操作的戏法。给定相同的输入，必定得出同样的输出。
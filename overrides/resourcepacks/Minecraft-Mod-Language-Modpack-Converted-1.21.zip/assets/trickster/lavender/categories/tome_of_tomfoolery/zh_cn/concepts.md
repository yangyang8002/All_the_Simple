```json
{
  "title": "概念",
  "icon": "trickster:top_hat",
  "ordinal": -1
}
```

本分类主要涉及普通魔术中一些有用的惯例和概念。

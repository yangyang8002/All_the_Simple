```json
{
  "title": "地底的星星⋯⋯",
  "icon": "minecraft:nether_star",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:trigger/nether_star"
  ],
  "secret": true,
  "ordinal": 24
}
```

在击败可怖的敌人后，其力量的一部分残余了下来。这颗来自地底的星星，来自火焰永燃、岩浆永流世界的星星，从未见过天空。如今它已自其主人的体内释放而出，它即是深渊的光。它的力量无物可当。

;;;;;

构建此等强大的能量源，花费的能量可能需要用“昆甘”计数。凋灵拥有如此强大的力量，为何它又会被击败？下界的星星必然有其局限，但到目前为止还未显现⋯⋯
```json
{
  "title": "魔术把戏秘典"
}
```

<|spell-preview@trickster:templates|spell=YwyT9+Z3YJjPxgRiMLg4cDGDGIwMDgyMIAZHCAMDg9azL5ogToCHQydYdIMPA0RakYGJEcwI4HHoxKcQaGAnE4TBwAEWYWBUQLICjxkLGhwaoVqZIArBDAYAAInoArsAAAA=|>

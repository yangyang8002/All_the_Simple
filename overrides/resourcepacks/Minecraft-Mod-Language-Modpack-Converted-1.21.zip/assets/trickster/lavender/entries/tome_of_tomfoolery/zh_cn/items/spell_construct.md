```json
{
  "title": "法术组构台",
  "icon": "trickster:spell_construct",
  "category": "trickster:items",
  "ordinal": 90
}
```

法术组构台是一种较为简单的设备，抄入法术再放置出来，即会持久施放所抄的法术。


组构台最适用于对世界中的变化产生反应，或是会周期性触发的[长时运行](^trickster:concepts/multi_tick)法术。

;;;;;

如果需要提供魔力源，可手持[晶结](^trickster:items/knots)右击组构台的中心以放入。还可Shift右击组构台以重置当前法术，并清除之前产生的失策。

<recipe;trickster:spell_construct>

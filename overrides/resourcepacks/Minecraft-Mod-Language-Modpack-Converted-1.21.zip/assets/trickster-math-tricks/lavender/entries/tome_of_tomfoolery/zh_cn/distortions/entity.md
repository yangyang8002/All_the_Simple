```json
{
  "title": "实体查询",
  "icon": "minecraft:cow_spawn_egg",
  "category": "trickster-math-tricks:math-tricks"
}
```

各类能获取实体信息的戏法。

;;;;;

<|glyph@trickster-math-tricks:templates|trick-id=trickster-math-tricks:entity_quaternion,title=旋向之辑流|>

entity -> quaternion

---

将所给实体头部的旋转方向返回为四元数。